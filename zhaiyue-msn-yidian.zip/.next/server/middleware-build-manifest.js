globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/u_gmBGlMqRz72G50BVQsG/_buildManifest.js",
    "static/u_gmBGlMqRz72G50BVQsG/_ssgManifest.js",
    "static/u_gmBGlMqRz72G50BVQsG/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2tu5-c6harjle.js",
    "static/chunks/2l0rb_yvf9lz8.js",
    "static/chunks/1ay12cd9dyje4.js",
    "static/chunks/2riolk3adx8rj.js",
    "static/chunks/turbopack-2c5dlso-2848_.js"
  ]
};
