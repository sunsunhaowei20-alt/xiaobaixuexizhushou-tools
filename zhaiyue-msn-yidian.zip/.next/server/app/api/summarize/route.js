var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/summarize/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__07ohvh7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_summarize_route_actions_0iw_jzl.js")
R.m(40499)
module.exports=R.m(40499).exports
