1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/08sy4nwafv-kx.js","/_next/static/chunks/3ixnum3-fm047.js","/_next/static/chunks/42suf91nv7d8r.js","/_next/static/chunks/1sz-nf_a8q9gq.js"],"default"]
3:I[37457,["/_next/static/chunks/08sy4nwafv-kx.js","/_next/static/chunks/3ixnum3-fm047.js","/_next/static/chunks/42suf91nv7d8r.js","/_next/static/chunks/1sz-nf_a8q9gq.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"u_gmBGlMqRz72G50BVQsG"}
