:HL["/_next/static/chunks/0hm1rsy9o782d.css","style"]
:HL["/_next/static/chunks/2_n_bc3e_bdag.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"u_gmBGlMqRz72G50BVQsG"}
